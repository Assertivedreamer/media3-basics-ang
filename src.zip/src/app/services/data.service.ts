import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private baseUrl =  [

    {
      'id':1,
      "aa" :'a',
      "vi":'bza'

    },

    {
      'id':2,
      "aa" :'b',
      "vi":'vizag'

    },
    {
      'id':3,
      "aa" :'c',
      "vi":'sri'

    },


  ];
  constructor(private http: HttpClient) { }

  signup() {
    return this.http.get<any>(`${this.baseUrl}`)
  }





}
