import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { bufferToggle } from 'rxjs';
import {MatButtonModule} from '@angular/material/button';
import {DataService} from "../../services/data.service";
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  myname ="ad";
  myname1 ="ad1";
   show1 :string="";
 @Input() par="";
 public  bb :string="";
  required=true;
  required1=true;

styg={

color:'blue',
fontStyle:"italic"
}
  hidden: any;
@Output()cmsg =new EventEmitter();
  private myPerson: any;
  private myError: any;

  constructor( private Jarwis: DataService) { }

  ngOnInit(): void {

    this.Jarwis.signup().subscribe(res => this.myPerson = res)

  }


  // @ts-ignore
  // show(data) {
  //
  //   this.show1= data;
  // }
  CopyText: string ="";
  qqqqq: any="2";


na=['b','c','d']


  naas ={
'id':1,
   "aa" :'b',
    "vi":'bza'

  }



 nested=
  [

    {
      'id':1,
      "aa" :'a',
      "vi":'bza'

    },

    {
      'id':2,
      "aa" :'b',
      "vi":'vizag'

    },
    {
      'id':3,
      "aa" :'c',
      "vi":'sri'

    },


  ]















  oncli() {
    // @ts-ignore
    this.cmsg.emit("child msg ffffffffffff cccccccccccc mmmmmmmmmm");
  }
}
